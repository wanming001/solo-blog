title: 基于SpringCloudAlibaba微服务架构nacos整合分布式事务框架seata(原名fescar)
date: '2019-11-22 20:59:25'
updated: '2019-11-25 08:54:23'
tags: [SpringCloud]
permalink: /articles/2019/11/22/1574427565376.html
---
![](https://img.hacpai.com/bing/20180201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## Seata的AT模式最佳实践
![fescar](https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=2073361104,2080458778&fm=15&gp=0.jpg")

#### 1.拉去seata官方的seata-server （[github地址](https://github.com/seata/seata)）

```
https://github.com/seata/seata/releases/download/v0.9.0/seata-server-0.9.0.tar.gz
```

#### 2.解压 seata-server-0.9.0.tar.gz

```
tar -zxvf seata-server-0.9.0.tar.gz
```

#### 3.进入seata/conf目录修改register.conf配置文件

```
registry {
	#基于naocs   serverAdd配置对应的nacos地址 namespace命名空间
	#另外还可以基于file 、eureka、redis、zk、consul、etcd3、sofa等可以做相关配置，这里就不一一操作了
  type = "nacos"
  nacos {
    serverAddr = "192.168.1.19:8848"
    namespace = "public"
    cluster = "default"
  }
}
config {
  type = "nacos"
  nacos {
    serverAddr = "192.168.1.19:8848"
    namespace = "public"
    cluster = "default"
  }
}
```

#### 4.修改nacos-config.txt

```
service.vgroup_mapping.vendor-system-fescar-service=default   #vendor-system-fescar-service配置事务组名，跟应用服务上配置一致，后面会提到
service.vgroup_mapping.vendor-position-fescar-service=default
```

#### 5.进入bin目录,修改启动脚本seata-server.sh ,防止发生内存泄漏问题

> -XX:MaxDirectMemorySize=2048m

#### 6.在naocs服务页面添加,值默认default(或者执行nacos-conf.sh脚本)
![在这里插入图片描述](https://user-gold-cdn.xitu.io/2019/11/22/16e92fbc9f556713?w=1431&h=232&f=png&s=43739)

#### 7.启动脚本文件，注意seata默认取的是服务器的内网ip,那么外部服务无法注册到seata-server上。那么就必须在启动参数指定外网ip "-h 47.125.114.58"

> sh seata-server.sh -h 47.125.114.58

服务启动成功
![在这里插入图片描述](https://user-gold-cdn.xitu.io/2019/11/22/16e92fbca0dcfaac?w=1447&h=126&f=png&s=44647)
#### 8.可以在nacos服务页面看到，seata服务注册成功
![在这里插入图片描述](https://user-gold-cdn.xitu.io/2019/11/22/16e92fbca1ee7a98?w=1519&h=239&f=png&s=32797)

#### 9.项目vendor-system配置 添加依赖

```
<!--seata事务组件-->
<dependency>
	<groupId>com.alibaba.cloud</groupId>
	<artifactId>spring-cloud-starter-alibaba-seata</artifactId>
</dependency>
```

#### 10.配置事务组

```
spring:
  cloud:
    alibaba:
      seata:
        tx-service-group: vendor-system-fescar-servic
```
		
#### 11.配置代理数据源,

```
@Configuration
@Import(DataSourcesProperties.class)
public class DataSourceProxyAutoConfiguration {

    private DataSourcesProperties dataSourcesProperties;

    public DataSourceProxyAutoConfiguration(DataSourcesProperties dataSourcesProperties) {
        this.dataSourcesProperties = dataSourcesProperties;
    }

    /**
     * create proxy datasource
     * @return
     */
    @Primary
    @Bean(name = "dataSource")
    public DataSource getDatasource(){
        HikariDataSource build = DataSourceBuilder.create().url(dataSourcesProperties.getUrl())
                .password(dataSourcesProperties.getPassword())
                .username(dataSourcesProperties.getUsername())
                .type(dataSourcesProperties.getType())
                .driverClassName(dataSourcesProperties.getDriverClassName()).build();
        return new DataSourceProxy(build);
    }

}
```
		
#### 12.配置fegin远程调用时xid的传输

```
public class FescarRequestInterceptor implements RequestInterceptor {

    private static final String FESCAR_HEADER_NAME = "Fescar-Xid";

    @Override
    public void apply(RequestTemplate requestTemplate) {
        String xid = RootContext.getXID();
        if(StringUtils.isNoneBlank(xid)){
            requestTemplate.header(FESCAR_HEADER_NAME,xid);
        }
    }
}
```

#### 13.复制上面的registry.conf文件到应用的resources目录，并且将seata\conf中的db_uodo_log.sql中的表初始化到每个应用的数据库中，做回滚的日志表



#### 14.测试在需要配置事务的方法上加@GlobalTransactional注解就可以了

#### 15.启动应用，控制台
![在这里插入图片描述](https://user-gold-cdn.xitu.io/2019/11/22/16e92fbca1d9e724?w=1851&h=161&f=png&s=43570)

#### 16.seata-server服务端控制台RM注册成功
![在这里插入图片描述](https://user-gold-cdn.xitu.io/2019/11/22/16e92fbca3b58757?w=1776&h=42&f=png&s=19951)

***
>  记住：牛逼的技术虽然不是你的，但是你会了，就是你的

