title: 《你不知道的java知识点》系列
date: '2019-12-07 11:32:31'
updated: '2019-12-07 11:32:31'
tags: [java]
permalink: /articles/2019/12/07/1575689551482.html
---
### <font color='#C43C57'>《你不知道的java知识点》系列之this关键字</font>

***



> #### <font color="#C43C57">**你们知道的**</font>

* 1.类的非静态方法都可以用this代表当前对象去调用
* 2.使用本类的属性时,都会隐式的使用this
* 3.区分成员属性和局部变量同名的情况
* 4.构造器中可以调用本类的其他构造函数



> #### <font color="#C43C57">**why:为什么类里面可以使用this关键字代表当前对象**</font>

> 先来一段代码

```
@SpringBootApplication
public class WebfluxApplication {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebfluxApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(WebfluxApplication.class, args);
    }

    @Bean
    public RouterFunction<ServerResponse> helloWorld(){
        testThis(3);
        LOGGER.info("create request mapping '/helloWorld' success");
        return RouterFunctions.route(RequestPredicates.GET("/helloWorld"),
                request->ok().body(Mono.just("helloWorld"),String.class));
    }

    private void testThis(WebfluxApplication this,int a){
        LOGGER.info(this.toString());
    }

}
```

<font color="#C43C57">__可以看到testThis()方法并不报错， 那么我们就可以大胆推断，非静态方法默认把当前对象作为形参的第一个参数，并且参数名为this.为什么是第一个参数，大家试试就知道，放在其他的位置就会报错。__</font>

> 进一步验证，我们去掉第一个参数this,使用bytecode-viewer反编译工具


![](https://user-gold-cdn.xitu.io/2019/12/7/16ede60cd5778fbf?w=1548&h=813&f=png&s=163225)

> 可以看见反编译后第一个参数依旧是this当前对象

#### 由此，我们可以得出的结论就是：在非静态方法中默认第一个参数就是当前对象,并且参数名是this.




***
>说十遍不如做一次 
>
>Better do it once than say it ten times.
